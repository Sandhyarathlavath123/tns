package Public1;

public class Public14 {

	public static void main(String[] args) {
	   Public11 obj1=new Public11();
			obj1.screen13();
		}


	}


