package Public1;

public class Public11 {
  void screen13() {
	System.out.println("success life12");
}

}
