package EVERYONECAN;

public class PUBLICA {
	public void sorry()
	{
	System.out.println("unfortunatly");
}

}
