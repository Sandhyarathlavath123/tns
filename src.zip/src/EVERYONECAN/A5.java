package EVERYONECAN;

public class A5 {
	protected void kalki() {
		System.out.println("mahabharatham");
	}

}
