package EVERYONECAN;

public class PUBLICB {

	public static void main(String[] args) {
		PUBLICA obj2=new PUBLICA();
		obj2.sorry();

	}

}
