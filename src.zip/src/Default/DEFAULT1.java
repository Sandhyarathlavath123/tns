package Default;

public class DEFAULT1 {

	public static void main(String[] args) {
		DEFAULT a1 =new DEFAULT();
		System.out.println("a1.a");
		a1.botton();
		System.out.println("DEFAULT.b");
		

	}

}
