package Default;

public class DEFAULT {
 void botton()
	 {
		 System.out.println(23);
	 }
 public static void main(String args[])
 {
	 DEFAULT obj33=new DEFAULT();
	 obj33.botton();
 }
}
