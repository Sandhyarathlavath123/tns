package EVERYONECAN2;
import EVERYONECAN.*;
public class A7 extends A5{

	public static void main(String[] args) {
		A7 obj3=new A7();
		obj3.kalki();

	}

}
