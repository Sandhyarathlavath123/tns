package Privatep1;

   public class A11 {
	private void screen12() {
		System.out.println("success life");
	}
	public static void main(String args[]) {
	  A11 obj=new A11();
	obj.screen12();

}
   }
