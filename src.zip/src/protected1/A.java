package protected1;

public class AAA {
protected void wow()
{
	System.out.println("welcome");
}
}
package protected2;
import protected1.*;
class B extends AAA
{
	public static void main(String args[])
	{
		B w1 =new B();
		w1.wow();
	}
}
