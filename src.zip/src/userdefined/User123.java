package userdefined;

public class User123 { 
		    int t=45;
			static int u=55;
				int display8()
				{
					return 40;
				}
				static void botton12()
				{
					System.out.println("65");
				}
				public static void main(String args[]) {
			User123 obj7=new User123();
			System.out.println("obj7.t");
			obj7.display8();
			System.out.println("User123.u");
			User123.botton12();

		}

		// TODO Auto-generated method stub

	}


