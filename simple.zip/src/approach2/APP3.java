package approach2;

public class APP3 {

	public static void main(String[] args) {
		APP2 y1=new APP2();
       System.out.println(y1.s);
       System.out.println(APP2.g);
       APP2.laptop1();
		
		

	}

}
