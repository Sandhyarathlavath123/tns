package approach2;

public class APP2 {
	int s=20;
	static int g=30;
	static void laptop1()
	{
		System.out.print(60);
	}

}
