package tns.day1;

public class Z {

	public static void main(String[] args) {
	
		System.out.println("hello world")// TODO Auto-generated method stub

	}

}
