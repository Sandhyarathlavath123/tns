package approach1;

public class APP1 {
	int x=10;
	static int y=20;
	int hub()
	{
		return 30;
	
	}
	static void hub1()
	{
		System.out.println("40");
	}

	public static void main(String[] args) {
		APP1 x1=new APP1();
				System.out.println(x1.x);
				x1.hub();
		System.out.println(APP1.y);
		APP1.hub1();
		
	
		}
		

	}


